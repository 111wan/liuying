from __future__ import annotations

import base64
import hashlib
import random
import re
import string
import time
import urllib.parse
from typing import TYPE_CHECKING, Any, TypedDict, cast

from yutto.types import UserInfo
from yutto.utils.fetcher import Fetcher, unwrap_fetch_result

if TYPE_CHECKING:
    from yutto.core.execution import ExecutionScope


class WbiImg(TypedDict):
    img_key: str
    sub_key: str


dm_img_str_cache: str = base64.b64encode("".join(random.choices(string.printable, k=random.randint(16, 64))).encode())[:-2].decode()  # fmt: skip
dm_cover_img_str_cache: str = base64.b64encode("".join(random.choices(string.printable, k=random.randint(32, 128))).encode())[:-2].decode()  # fmt: skip
USER_INFO_API = "https://api.bilibili.com/x/web-interface/nav"


def parse_user_info(res_json: dict[str, Any]) -> UserInfo:
    res_json_data_any = res_json.get("data")
    if not isinstance(res_json_data_any, dict):
        raise ValueError(f"获取用户信息失败，返回值异常：{res_json}")
    res_json_data = cast("dict[str, Any]", res_json_data_any)
    return UserInfo(
        vip_status=res_json_data.get("vipStatus") == 1,  # API 返回的是 int，如果未登录就没这个值
        is_login=bool(res_json_data.get("isLogin")),  # API 返回的是 bool
    )


async def get_user_info(scope: ExecutionScope) -> UserInfo:
    if scope.user_info_cache is not None:
        return scope.user_info_cache
    async with scope.user_info_lock:
        if scope.user_info_cache is None:
            res_json = unwrap_fetch_result(await Fetcher.fetch_json(scope, USER_INFO_API))
            scope.user_info_cache = parse_user_info(res_json)
        return scope.user_info_cache


def user_info_matches(user_info: UserInfo, check_option: UserInfo) -> bool:
    if check_option["is_login"] and not user_info["is_login"]:
        return False
    if check_option["vip_status"] and not user_info["vip_status"]:
        return False
    return True


async def validate_user_info(scope: ExecutionScope, check_option: UserInfo) -> bool:
    """UserInfo 结构和用户输入是匹配的，如果要校验则置 True 即可，估计不会有要校验为 False 的情况吧~~"""
    if not check_option["is_login"] and not check_option["vip_status"]:
        return True

    if scope.user_info_cache is not None:
        return user_info_matches(scope.user_info_cache, check_option)

    user_info = await get_user_info(scope)
    return user_info_matches(user_info, check_option)


async def get_wbi_img(scope: ExecutionScope) -> WbiImg:
    if scope.wbi_img_cache is not None:
        return cast("WbiImg", scope.wbi_img_cache)
    async with scope.wbi_img_lock:
        if scope.wbi_img_cache is None:
            res_json = unwrap_fetch_result(await Fetcher.fetch_json(scope, USER_INFO_API))
            wbi_img: WbiImg = {
                "img_key": _get_key_from_url(res_json["data"]["wbi_img"]["img_url"]),
                "sub_key": _get_key_from_url(res_json["data"]["wbi_img"]["sub_url"]),
            }
            scope.wbi_img_cache = {
                "img_key": wbi_img["img_key"],
                "sub_key": wbi_img["sub_key"],
            }
        return cast("WbiImg", scope.wbi_img_cache)


def _get_key_from_url(url: str) -> str:
    return url.split("/")[-1].split(".")[0]


def _get_mixin_key(string: str) -> str:
    char_indices = [
        46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5,
        49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55,
        40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57,
        62, 11, 36, 20, 34, 44, 52,
    ]  # fmt: skip
    return "".join([string[idx] for idx in char_indices[:32]])


def encode_wbi(params: dict[str, Any], wbi_img: WbiImg) -> dict[str, Any]:
    img_key = wbi_img["img_key"]
    sub_key = wbi_img["sub_key"]
    illegal_char_remover = re.compile(r"[!'\(\)*]")

    mixin_key = _get_mixin_key(img_key + sub_key)
    time_stamp = int(time.time())
    params_with_wts = dict(params, wts=time_stamp)
    params_with_dm = {
        **params_with_wts,
        "dm_img_list": "[]",
        "dm_img_str": dm_img_str_cache,
        "dm_cover_img_str": dm_cover_img_str_cache,
    }
    url_encoded_params = urllib.parse.urlencode(
        {
            key: illegal_char_remover.sub("", str(params_with_dm[key]))
            for key in sorted(params_with_dm.keys())
        }
    )  # fmt: skip
    w_rid = hashlib.md5((url_encoded_params + mixin_key).encode()).hexdigest()
    all_params = dict(params_with_dm, w_rid=w_rid)
    return all_params
