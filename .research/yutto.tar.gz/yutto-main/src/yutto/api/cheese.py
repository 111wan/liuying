from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypedDict

from returns.result import Failure

from yutto.core.operation import ReportLevel, emit_download_report
from yutto.exceptions import NoAccessPermissionError, UnSupportedTypeError
from yutto.media.codec import audio_codec_map, video_codec_map
from yutto.types import (
    AId,
    AudioUrlMeta,
    CId,
    EpisodeId,
    SeasonId,
    VideoUrlMeta,
    format_ids,
)
from yutto.utils.fetcher import Fetcher, unwrap_fetch_result
from yutto.utils.functional import data_has_chained_keys
from yutto.utils.metadata import MetaData
from yutto.utils.time import get_time_stamp_by_now

if TYPE_CHECKING:
    from yutto.core.execution import ExecutionScope
    from yutto.types import (
        AvId,
        MultiLangSubtitle,
    )


class CheeseListItem(TypedDict):
    id: int
    name: str
    cid: CId
    episode_id: EpisodeId
    avid: AvId
    metadata: MetaData


class CheeseList(TypedDict):
    title: str
    pages: list[CheeseListItem]


async def get_season_id_by_episode_id(scope: ExecutionScope, episode_id: EpisodeId) -> SeasonId:
    home_url = f"https://api.bilibili.com/pugv/view/web/season?ep_id={episode_id}"
    res_json = unwrap_fetch_result(await Fetcher.fetch_json(scope, home_url))
    return SeasonId(str(res_json["data"]["season_id"]))


async def get_cheese_list(scope: ExecutionScope, season_id: SeasonId) -> CheeseList:
    list_api = "https://api.bilibili.com/pugv/view/web/season?season_id={season_id}"
    list_result = await Fetcher.fetch_json(scope, list_api.format(season_id=season_id))
    if isinstance(list_result, Failure):
        raise NoAccessPermissionError(f"无法解析该课程列表（season_id: {season_id}）") from list_result.failure()
    resp_json = list_result.unwrap()
    if resp_json.get("data") is None:
        raise NoAccessPermissionError(f"无法解析该课程列表（season_id: {season_id}），原因：{resp_json.get('message')}")
    result = resp_json["data"]
    section_episodes = result["episodes"]
    return CheeseList(
        title=result["title"],
        pages=[
            CheeseListItem(
                id=i + 1,
                name=item["title"],
                cid=CId(str(item["cid"])),
                episode_id=EpisodeId(str(item["id"])),
                avid=AId(str(item["aid"])),
                metadata=_parse_cheese_metadata(item),
            )
            for i, item in enumerate(section_episodes)
        ],
    )


async def get_cheese_playurl(
    scope: ExecutionScope, avid: AvId, episode_id: EpisodeId, cid: CId
) -> tuple[list[VideoUrlMeta], list[AudioUrlMeta]]:
    play_api = (
        "https://api.bilibili.com/pugv/player/web/playurl?avid={aid}&cid={"
        "cid}&qn=80&fnver=0&fnval=16&fourk=1&ep_id={episode_id}&from_client=BROWSER&drm_tech_type=2"
    )
    play_result = await Fetcher.fetch_json(scope, play_api.format(**avid.to_dict(), cid=cid, episode_id=episode_id))
    if isinstance(play_result, Failure):
        raise NoAccessPermissionError(f"无法获取该视频链接（{format_ids(avid, cid)}）") from play_result.failure()
    resp_json = play_result.unwrap()
    if resp_json.get("data") is None:
        raise NoAccessPermissionError(
            f"无法获取该视频链接（{format_ids(avid, cid)}），原因：{resp_json.get('message')}"
        )
    if resp_json["data"]["is_preview"] == 1:
        emit_download_report(
            f"视频（{format_ids(avid, cid)}）是预览视频（疑似未登录或非大会员用户）",
            ReportLevel.WARNING,
        )
    if resp_json["data"].get("dash") is None:
        raise UnSupportedTypeError(f"该视频（{format_ids(avid, cid)}）尚不支持 DASH 格式")
    return (
        [
            VideoUrlMeta(
                url=video["base_url"],
                mirrors=video["backup_url"] if video["backup_url"] is not None else [],
                codec=video_codec_map[video["codecid"]],
                width=video["width"],
                height=video["height"],
                quality=video["id"],
            )
            for video in resp_json["data"]["dash"]["video"]
        ],
        [
            AudioUrlMeta(
                url=audio["base_url"],
                mirrors=audio["backup_url"] if audio["backup_url"] is not None else [],
                codec=audio_codec_map[audio["codecid"]],
                width=0,
                height=0,
                quality=audio["id"],
            )
            for audio in resp_json["data"]["dash"]["audio"]
        ],
    )


async def get_cheese_subtitles(scope: ExecutionScope, avid: AvId, cid: CId) -> list[MultiLangSubtitle]:
    subtitle_api = "https://api.bilibili.com/x/player/v2?cid={cid}&aid={aid}&bvid={bvid}"
    subtitle_url = subtitle_api.format(**avid.to_dict(), cid=cid)
    subtitles_json_info = (await Fetcher.fetch_json(scope, subtitle_url)).value_or(None)
    if subtitles_json_info is None:
        return []
    if not data_has_chained_keys(subtitles_json_info, ["data", "subtitle", "subtitles"]):
        emit_download_report(
            f"无法获取该视频的字幕（{format_ids(avid, cid)}），原因：{subtitles_json_info.get('message')}",
            ReportLevel.WARNING,
        )
        return []
    subtitles_info = subtitles_json_info["data"]["subtitle"]
    results: list[MultiLangSubtitle] = []
    for sub_info in subtitles_info["subtitles"]:
        subtitle_url = sub_info["subtitle_url"]

        # 检查 subtitle_url 是否有效
        if subtitle_url is None or not subtitle_url.strip():
            emit_download_report(
                f"跳过无效的字幕URL（{format_ids(avid, cid)}），语言：{sub_info.get('lan_doc', '未知')}",
                ReportLevel.WARNING,
            )
            continue

        subtitle_text = (await Fetcher.fetch_json(scope, "https:" + subtitle_url)).value_or(None)
        if subtitle_text is None:
            continue
        results.append(
            {
                "lang": sub_info["lan_doc"],
                "lines": subtitle_text["body"],
            }
        )

    return results


def _parse_cheese_metadata(item: dict[str, Any]) -> MetaData:
    return MetaData(
        title=item["title"],
        show_title=item["title"],  # 无此字段，用 title 代替
        plot=item["title"],  # 无此字段，用 title 代替
        thumb=item["cover"],
        premiered=item["release_date"],
        dateadded=get_time_stamp_by_now(),
        source="",  # TODO
        actor=[],  # TODO
        genre=[],  # TODO
        tag=[],  # TODO
        website="",  # TODO
        original_filename="",  # TODO
        chapter_info_data=[],  # There are no chapter info in cheese for now
    )
