from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from yutto.core.events import (
    DownloadArtifactCreated,
    DownloadBatchStarted,
    DownloadEventSink,
    DownloadItemListed,
    DownloadItemSkipped,
    DownloadMediaSelected,
    DownloadProgress,
    DownloadRequestQueued,
    DownloadStage,
    DownloadStageChanged,
    SelectedAudioStream,
    SelectedVideoStream,
)
from yutto.core.execution import ExecutionScopeFactory, RequestExecutionScopeFactory
from yutto.core.operation import emit_download_event
from yutto.core.request import DownloadRequest
from yutto.core.result import DownloadResult, ItemSkipReason, ResolvedItem
from yutto.core.task_service import DownloadTaskService, _encode_runtime_event
from yutto.runtime import TaskState
from yutto.types import AId, CId
from yutto.utils.functional import as_sync

if TYPE_CHECKING:
    from collections.abc import Iterator

pytestmark = pytest.mark.processor


def task_ids() -> Iterator[str]:
    index = 0
    while True:
        index += 1
        yield f"download-{index}"


class RecordingApplication:
    def __init__(
        self,
        scope_factory: ExecutionScopeFactory,
        event_sink: DownloadEventSink,
        calls: list[tuple[ExecutionScopeFactory, str]],
    ):
        self.scope_factory = scope_factory
        self.event_sink = event_sink
        self.calls = calls
        self.result = DownloadResult()

    async def download(self, request: DownloadRequest) -> DownloadResult:
        self.event_sink.emit(DownloadStageChanged(name=DownloadStage.RESOLVING))
        self.event_sink.emit(
            DownloadMediaSelected(
                item="video",
                video=SelectedVideoStream(
                    codec="av1",
                    quality=120,
                    width=3840,
                    height=2160,
                    save_codec="copy",
                ),
                audio=None,
            )
        )
        self.calls.append((self.scope_factory, request.source.url))
        return self.result


@as_sync
async def test_download_task_service_runs_requests_in_order_and_bridges_events():
    ids = task_ids()
    scope_factory = RequestExecutionScopeFactory()
    calls: list[tuple[ExecutionScopeFactory, str]] = []

    def application_factory(
        factory: ExecutionScopeFactory,
        event_sink: DownloadEventSink,
    ) -> RecordingApplication:
        return RecordingApplication(factory, event_sink, calls)

    service = DownloadTaskService(
        scope_factory,
        application_factory=application_factory,
        task_id_factory=lambda: next(ids),
    )
    async with service:
        first = await service.submit(DownloadRequest.model_validate({"source": {"url": "BV1first"}}))
        second = await service.submit(DownloadRequest.model_validate({"source": {"url": "BV1second"}}))
        first_done = await service.runtime.wait(first.task_id)
        second_done = await service.runtime.wait(second.task_id)

        assert first_done is not None and second_done is not None
        assert first_done.state is TaskState.COMPLETED
        assert second_done.state is TaskState.COMPLETED
        assert first_done.result == DownloadResult()
        assert second_done.result == DownloadResult()
        assert [url for _, url in calls] == ["BV1first", "BV1second"]
        assert all(factory is scope_factory for factory, _ in calls)
        first_replay = service.replay(first.task_id)
        assert first_replay is not None
        assert [(event.kind, event.data) for event in first_replay.events if event.kind == "stage"] == [
            ("stage", {"name": "resolving"})
        ]
        selected = [event for event in first_replay.events if event.kind == "media_selected"]
        assert len(selected) == 1
        assert selected[0].data["video"] == {
            "codec": "av1",
            "quality": 120,
            "width": 3840,
            "height": 2160,
            "save_codec": "copy",
        }


@as_sync
async def test_download_task_service_runs_up_to_worker_count_concurrently():
    scope_factory = RequestExecutionScopeFactory()
    both_started = asyncio.Event()
    release = asyncio.Event()
    active = 0
    max_active = 0

    class ConcurrentApplication:
        async def download(self, request: DownloadRequest) -> DownloadResult:
            nonlocal active, max_active
            active += 1
            max_active = max(max_active, active)
            if active == 2:
                both_started.set()
            try:
                await release.wait()
                return DownloadResult()
            finally:
                active -= 1

    service = DownloadTaskService(
        scope_factory,
        application_factory=lambda factory, event_sink: ConcurrentApplication(),
        worker_count=2,
    )
    async with service:
        first = await service.submit(DownloadRequest.model_validate({"source": {"url": "BV1first"}}))
        second = await service.submit(DownloadRequest.model_validate({"source": {"url": "BV1second"}}))
        await asyncio.wait_for(both_started.wait(), timeout=1)
        release.set()
        first_done, second_done = await asyncio.gather(
            service.runtime.wait(first.task_id),
            service.runtime.wait(second.task_id),
        )

    assert first_done is not None and first_done.state is TaskState.COMPLETED
    assert second_done is not None and second_done.state is TaskState.COMPLETED
    assert max_active == 2


@as_sync
async def test_download_events_are_noop_outside_application_context():
    emit_download_event(DownloadProgress(current=1, total=2, speed_per_second=3.0))


@pytest.mark.parametrize(
    ("event", "expected"),
    [
        (DownloadBatchStarted(total=2), ("batch_started", {"total": 2})),
        (
            DownloadRequestQueued(url="BV1test", index=1, total=2),
            ("request_queued", {"url": "BV1test", "index": 1, "total": 2}),
        ),
        (
            DownloadStageChanged(name=DownloadStage.PREPARING, item="video"),
            ("stage", {"name": "preparing", "item": "video"}),
        ),
        (
            DownloadProgress(current=1, total=2, speed_per_second=3.0, buffered_bytes=1, item="video"),
            (
                "progress",
                {
                    "phase": "downloading",
                    "current": 1,
                    "total": 2,
                    "speed_per_second": 3.0,
                    "unit": "bytes",
                    "item": "video",
                },
            ),
        ),
        (
            DownloadMediaSelected(
                item="video",
                video=SelectedVideoStream(
                    codec="av1",
                    quality=120,
                    width=3840,
                    height=2160,
                    save_codec="copy",
                ),
                audio=SelectedAudioStream(codec="mp4a", quality=30280, save_codec="copy"),
            ),
            (
                "media_selected",
                {
                    "item": "video",
                    "video": {
                        "codec": "av1",
                        "quality": 120,
                        "width": 3840,
                        "height": 2160,
                        "save_codec": "copy",
                    },
                    "audio": {
                        "codec": "mp4a",
                        "quality": 30280,
                        "save_codec": "copy",
                    },
                },
            ),
        ),
        (
            DownloadItemSkipped(item="video", reason=ItemSkipReason.ALREADY_EXISTS),
            ("item_skipped", {"item": "video", "reason": "already_exists"}),
        ),
        (
            DownloadArtifactCreated(item="video", path=Path("video.mp4")),
            ("artifact_created", {"path": "video.mp4", "item": "video"}),
        ),
    ],
)
def test_runtime_event_encoding_preserves_protocol(event, expected):
    assert _encode_runtime_event(event) == expected


def test_encode_runtime_event_media_selected_omits_urls_and_handles_missing_streams():
    kind, data = _encode_runtime_event(
        DownloadMediaSelected(
            item="audio-only",
            video=None,
            audio=SelectedAudioStream(codec="flac", quality=30251, save_codec="flac"),
        )
    )

    assert kind == "media_selected"
    assert data == {
        "item": "audio-only",
        "video": None,
        "audio": {"codec": "flac", "quality": 30251, "save_codec": "flac"},
    }
    assert "url" not in repr(data).casefold()


def test_encode_runtime_event_item_listed_carries_full_wire_fields():
    item = ResolvedItem(
        avid=AId("1"),
        cid=CId("10"),
        url="https://www.bilibili.com/video/av1?p=1",
        name="P1",
        title="标题",
        cover_url="https://example.com/cover.jpg",
        planned_path=Path("标题/P1"),
        display_group="标题",
        uploader="某UP主",
        description="视频简介",
        tags=("标签A", "标签B"),
        pubdate=1698148800,
        duration=1559,
    )
    kind, data = _encode_runtime_event(DownloadItemListed(item=item))
    assert kind == "item_listed"
    assert data["avid"] == "1"
    assert data["cid"] == "10"
    assert data["planned_path"] == "标题/P1"
    assert data["tags"] == ["标签A", "标签B"]
    assert data["pubdate"] == 1698148800
    assert data["duration"] == 1559
