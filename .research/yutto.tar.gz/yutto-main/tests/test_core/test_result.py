from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from yutto.core.result import (
    Artifact,
    ArtifactKind,
    DownloadResult,
    ItemResult,
    ItemSkipReason,
    ItemState,
    ResolvedItem,
    ResolveResult,
)
from yutto.types import AId, BvId, CId

pytestmark = pytest.mark.processor


def test_result_models_are_frozen_and_reject_extra_fields():
    result = DownloadResult()

    with pytest.raises(ValidationError, match="frozen"):
        result.items = ()  # ty: ignore[invalid-assignment]
    with pytest.raises(ValidationError, match="Extra inputs"):
        Artifact(kind=ArtifactKind.MEDIA, path=Path("video.mp4"), size=1)  # ty: ignore[unknown-argument]


def test_resolved_item_is_a_typed_immutable_listing_snapshot():
    payload: dict[str, object] = {
        "avid": AId("1"),
        "cid": CId("10"),
        "url": "https://www.bilibili.com/video/av1?p=1",
        "name": "P1",
        "title": "标题",
        "cover_url": "https://example.com/cover.jpg",
        "planned_path": Path("标题/P1"),
        "display_group": "标题",
        "uploader": "某UP主",
        "description": "视频简介",
        "tags": ("标签A", "标签B"),
        "pubdate": 1698148800,
        "duration": 1559,
    }
    item = ResolvedItem.model_validate(payload)

    assert isinstance(item.avid, AId)
    assert isinstance(item.cid, CId)
    assert item.tags == ("标签A", "标签B")
    assert set(type(item).model_fields) == set(payload)
    serialized = item.model_dump(mode="json")
    assert serialized["avid"] == "1"
    assert serialized["cid"] == "10"
    assert serialized["planned_path"] == "标题/P1"
    assert serialized["tags"] == ["标签A", "标签B"]
    assert serialized["pubdate"] == 1698148800
    assert serialized["duration"] == 1559
    schema = ResolvedItem.model_json_schema(mode="serialization")
    assert schema["properties"]["avid"]["type"] == "string"
    assert schema["properties"]["cid"]["type"] == "string"

    with pytest.raises(ValidationError, match="frozen"):
        item.name = "changed"  # ty: ignore[invalid-assignment]
    with pytest.raises(ValidationError, match="Extra inputs"):
        ResolvedItem.model_validate({**payload, "play_url": "https://example.com/expiring"})


@pytest.mark.parametrize("avid", [AId("808982399"), BvId("BV1f34y1k7D5"), BvId("bv1f34y1k7D5")])
def test_listing_results_round_trip_through_json_with_typed_ids(avid: AId | BvId):
    cid = CId("144541892")
    item = ResolvedItem(
        avid=avid,
        cid=cid,
        url="https://www.bilibili.com/video/av808982399?p=1",
        name="P1",
        title="标题",
        cover_url="https://example.com/cover.jpg",
        planned_path=Path("标题/P1"),
        tags=("标签A", "标签B"),
    )
    assert item.avid is avid
    assert item.cid is cid

    restored_item = ResolvedItem.model_validate_json(item.model_dump_json())
    restored_result = ResolveResult.model_validate_json(ResolveResult(items=(item,)).model_dump_json())

    assert restored_item == item
    assert type(restored_item.avid) is type(avid)
    assert isinstance(restored_item.cid, CId)
    assert restored_result.items == (item,)
    assert type(restored_result.items[0].avid) is type(avid)
    assert isinstance(restored_result.items[0].cid, CId)


def test_item_result_validates_skip_reason_without_requiring_artifacts():
    resource_only = ItemResult(state=ItemState.DONE, output_path=Path("video.mp4"))
    media_download = ItemResult(
        state=ItemState.DONE,
        output_path=Path("video.mp4"),
        artifacts=(Artifact(kind=ArtifactKind.MEDIA, path=Path("video.mp4")),),
    )
    existing_media = ItemResult(
        state=ItemState.SKIPPED,
        output_path=Path("video.mp4"),
        skip_reason=ItemSkipReason.ALREADY_EXISTS,
        artifacts=(Artifact(kind=ArtifactKind.MEDIA, path=Path("video.mp4")),),
    )

    assert resource_only.artifacts == ()
    assert resource_only.has_downloaded_media is False
    assert media_download.has_downloaded_media is True
    assert existing_media.has_downloaded_media is False
    assert (
        ItemResult(
            state=ItemState.SKIPPED,
            output_path=Path("video.mp4"),
            skip_reason=ItemSkipReason.NO_MEDIA_STREAM,
        ).skip_reason
        is ItemSkipReason.NO_MEDIA_STREAM
    )

    with pytest.raises(ValidationError, match="done item must not have"):
        ItemResult(
            state=ItemState.DONE,
            output_path=Path("video.mp4"),
            skip_reason=ItemSkipReason.ALREADY_EXISTS,
        )
    with pytest.raises(ValidationError, match="skipped item must have"):
        ItemResult(state=ItemState.SKIPPED, output_path=Path("video.mp4"))
