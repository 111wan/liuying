from __future__ import annotations

import re
from typing import TYPE_CHECKING
from urllib.parse import parse_qs, urlparse

from yutto.api.ugc_video import get_ugc_video_list
from yutto.core.operation import ReportLevel, emit_download_report
from yutto.exceptions import (
    HttpStatusError,
    NoAccessPermissionError,
    NotFoundError,
    UnSupportedTypeError,
)
from yutto.extractor._abc import SingleExtractor
from yutto.extractor.common import make_ugc_video_episode
from yutto.extractor.outcome import ResolveOutcome
from yutto.types import AId, BvId

if TYPE_CHECKING:
    from yutto.core.execution import ExecutionScope
    from yutto.extractor._abc import ExtractorResolveOutcome
    from yutto.types import AvId, ExtractorOptions


class UgcVideoExtractor(SingleExtractor):
    """投稿视频单视频"""

    REGEX_AV = re.compile(r"https?://www\.bilibili\.com/video/av(?P<aid>\d+)/?")
    REGEX_BV = re.compile(r"https?://www\.bilibili\.com/video/(?P<bvid>(bv|BV)\w+)/?")

    REGEX_AV_ID = re.compile(r"av(?P<aid>\d+)(\?p=(?P<page>\d+))?")
    REGEX_BV_ID = re.compile(r"(?P<bvid>(bv|BV)\w+)(\?p=(?P<page>\d+))?")

    REGEX_BV_SPECIAL_PAGE = re.compile(r"https?://www\.bilibili\.com/festival/.+(?P<bvid>(bv|BV)\w+)")

    page: int
    avid: AvId

    def resolve_shortcut(self, id: str) -> tuple[bool, str]:
        matched = False
        url = id
        if match_obj := self.REGEX_AV_ID.match(id):
            page: int = 1
            if match_obj.group("page") is not None:
                page = int(match_obj.group("page"))
            url = f"https://www.bilibili.com/video/av{match_obj.group('aid')}?p={page}"
            matched = True
        elif match_obj := self.REGEX_BV_ID.match(id):
            page: int = 1
            if match_obj.group("page") is not None:
                page = int(match_obj.group("page"))
            url = f"https://www.bilibili.com/video/{match_obj.group('bvid')}?p={page}"
            matched = True
        return matched, url

    def match(self, url: str) -> bool:
        if (
            (match_obj := self.REGEX_AV.match(url))
            or (match_obj := self.REGEX_BV.match(url))
            or (match_obj := self.REGEX_BV_SPECIAL_PAGE.match(url))
        ):
            self.page: int = 1
            if "aid" in match_obj.groupdict().keys():
                self.avid = AId(match_obj.group("aid"))
            else:
                self.avid = BvId(match_obj.group("bvid"))
            query_params = parse_qs(urlparse(url).query)
            if p_queries := query_params.get("p"):
                try:
                    assert len(p_queries) == 1, f"p should only have one value in url `{url}`, but got {len(p_queries)}"
                    self.page = int(p_queries[0])
                except (ValueError, AssertionError) as e:
                    emit_download_report(
                        f"url 的 page 信息不正确, `{e}`, 请检查 `p=` 的值是否为整数且唯一～",
                        ReportLevel.ERROR,
                    )
                    return False
            return True
        else:
            return False

    async def extract(
        self,
        scope: ExecutionScope,
        options: ExtractorOptions,
    ) -> ExtractorResolveOutcome:
        try:
            ugc_video_list = await get_ugc_video_list(scope, self.avid)
            self.avid = ugc_video_list["avid"]  # 当视频撞车时，使用新的 avid 替代原有 avid，见 #96
            emit_download_report(ugc_video_list["title"], badge="投稿视频")
            return ResolveOutcome(
                items=(
                    make_ugc_video_episode(
                        scope,
                        self.avid,
                        ugc_video_list["pages"][self.page - 1],
                        options,
                        {
                            "title": ugc_video_list["title"],
                            "pubdate": ugc_video_list["pubdate"],
                        },
                        "{title}",
                    ),
                )
            )
        except (NoAccessPermissionError, HttpStatusError, UnSupportedTypeError, NotFoundError) as e:
            emit_download_report(e.message, ReportLevel.ERROR)
            return ResolveOutcome(failures=(e,))
