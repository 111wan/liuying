from cx_Freeze import setup, Executable


build_exe_options = {
    "packages": [
        "rich",
        "uvicorn",
    ],
    "include_files": [
        ("locale", "locale"),
    ],
    "include_msvcr": True,
}

executables = [
    Executable(
        script="main.py",
        icon="./docs/KS-Downloader",
        target_name="KS-Downloader",
    )
]

setup(
    name="KS-Downloader",
    options={"build_exe": build_exe_options},
    executables=executables,
)
